import socket
import sqlite3,time,sys
host = "127.0.0.1"  # ip
port = 5000#int(input("Set port: "))
server = socket.socket()
server.bind((host, port))   # ผูก object เข้ากับ host port
server.listen(1)  # กำหนดจำนวน client
print("รอการเชื่อมต่อจาก client :")
client, addr = server.accept()  # method นี้จะยืนยันว่า client ได้เชื่อมกับ server แล้ว และเก็บค่าใน client,addr
print("Connected From : "+str(addr))

def history():
    with sqlite3.connect("FoodService.db") as db:
        cur = db.cursor()
        u = cur.execute("select* from bill")
        l = u.fetchall()
        print('จำนวนสมาชิก :', len(l), '\tคน')  # แสดงชข้อมูลในDB
        for i in range(len(l)):
            print(l[i])

def UsersList():
    with sqlite3.connect("FoodService.db") as db:
        cur = db.cursor()
        u = cur.execute("select username from users")
        l = u.fetchall()
        print('จำนวนสมาชิก :', len(l), '\tคน')  # แสดงชข้อมูลในDB
        for i in range(len(l)):
            print(l[i])


def login(name,p):

   while True:
       username = name
       password = p
       with sqlite3.connect("FoodService.db") as db:
           cur = db.cursor()
       find_user = ("select * from users where username =? and password =?")
       cur.execute(find_user,[(username),(password)])
       result = cur.fetchall()
       if result:
           for i in result:
               print("Username: "+i[0])
           return ("exit")
           break
       else:
           print("Username and password not regnised")
           again = input("Do you want to try again?(y/n): ")
           if again.lower()=='n':
               print("good bey")
               time.sleep(1)
               #return ("exit")
               break

def newUser(name,p,p1):
   found = 0
   while found == 0:
       username = name
       with sqlite3.connect("FoodService.db") as db:
           cur = db.cursor()
       find_user = ("select * from users where username =?")
       cur.execute(find_user,[(username)])

       if cur.fetchall():
           print("Username Taken, Please try again")
       else:
           found = 1

   username = name
   password = p
   passwor1 = p1
   InsertData = '''insert into users(username,password) values(?,?)'''
   cur.execute(InsertData,[(username),(password)])
   db.commit()

def status():
    while True:
        print('-----------------------')
        manu = ('''
                    1. ยืนยันรายการของท่านเรียบร้อยแล้ว
                    2. อยู่ในระหว่างการจัดส่ง
                    3. จัดส่งเรียบร้อยแล้ว
                   ''')
        print(manu)
        ch = input('กรุณาแจ้งสถานะ:')
        if ch == '1':
            data1 = 'ยืนยันรายการของท่านเรียบร้อยแล้ว'  # ข้อความที่เตรียมส่งให้client
            client.send(data1.encode('utf-8'))
        elif ch == '2':
            data1 = 'อยู่ในระหว่างการจัดส่ง'
            client.send(data1.encode('utf-8'))
        elif ch == '3':
            data1 = 'จัดส่งเรียบร้อยแล้วค่ะ/ครับ'
            client.send(data1.encode('utf-8'))
            break


while True:
   # รับข้อมูลจาก Client
   data = client.recv(1024).decode('utf-8')  # 1024byte หรือ 1024 ตัวอักษร และแปลง byte เป็น string
   if not data:
       break
   elif data =='newUser':
       name = client.recv(1024).decode('utf-8')
       p = client.recv(1024).decode('utf-8')
       p1 = client.recv(1024).decode('utf-8')
       newUser(name,p,p1)
       print("client: " + data)#print ข้อความที่ clientส่งมา
       data1 = 'Your Account created!!!! ' #ข้อความที่เตรียมส่งให้client
       client.send(data1.encode('utf-8'))#ส่งไปหาclient
   elif data == 'login':
       name = client.recv(1024).decode('utf-8')
       p = client.recv(1024).decode('utf-8')
       login(name,p)
       print("client: " + data)  # print ข้อความที่ clientส่งมา
       data1 = str(name)  # ข้อความที่เตรียมส่งให้client
       client.send(data1.encode('utf-8'))  # ส่งไปหาclient
   elif data == 'ยืนยันคำสั่งซื้อเรียบร้อย':
       status()



client.close()



