import  socket
import sqlite3 as DB,time,sys

host = "127.0.0.1"
port = 5000
server = socket.socket()
server.connect((host,port))
con = DB.connect("FoodService.db")
with con :
    cur = con.cursor()

def addDB(list):
    data = list
    for i in range(len(data)):
        cur.execute("insert into bill values(?,?,?,?)", data[i])

def UsersList():
    u = cur.execute("select * from users")
    l = u.fetchall()
    print('จำนวนสมาชิก :', len(l), '\tคน')  # แสดงชข้อมูลในDB
    for i in range(len(l)):
        print(i + 1)
        print('username :', l[i][0])
        print('password :', l[i][1])
        print('-----------------------------')

def history():
    u = cur.execute("select * from bill")
    l = u.fetchall()
    print('จำนวนรายการสั่งซื้อ :', len(l), '\tรายการ')  # แสดงชข้อมูลในDB
    for i in range(len(l)):
        print('รายการที่ ', i+1)
        print('ชื่อเมนู: ', l[i][0])
        print('จำนวน: ', l[i][1])
        print('Total: ', l[i][2])
        print('User: ', l[i][3])  # แสดงชข้อมูลในDB
        print('--------------------------------')

def food(name):
    while True:

        print('++++ ยินดีต้อนสู่ร้าน ซาลาเปาและขนมปังปิ้ง ++++')
        manu = ('''   --------------------- MANU --------------------
                       1.ไส้หมูไข่เค็ม                 ราคา   10   บาท
                       2.ไส้ถั่วหวาน                  ราคา   10   บาท
                       3.ไส้หมูแดง                   ราคา   10   บาท
                       4.ไส้เผือก                    ราคา   10   บาท
                       5.ไส้ครีม                     ราคา   10   บาท
                       6.ขนมปังปิ้งเนยนม               ราคา   20   บาท
                       7.ขนมปังปิ้งแยมสตอเบอร์รี่          ราคา   20   บาท
                       8.ขนมปังปิ้งเนย นม ช็อกโกแลต      ราคา   25   บาท
                       9.ขนมปังปิ้งแย้มส้ม               ราคา   20   บาท
                       10.น้ำเปล่า                     ราคา   7   บาท
                       11. ย้อนกลับ
                       ''')
        print(manu)
        usermanulist = []
        manulist = ()
        totallist = 0
        ch = 'y'
        while ch != 'n':
            select = input("เลือกเมนูที่ : ")
            if select == '1':
                Qty = int(input("จำนวน : "))
                foodname = 'ซาลาเปาไส้หมูไข่เค็ม'
                total = 10*Qty
                totallist = total+totallist
                manulist = (foodname,Qty,total,name)
                usermanulist.append(manulist)

            elif select == '2':
                foodname = 'ซาลาเปาไส้ถั่วหวาน'
                Qty = int(input("จำนวน : "))
                total = 10*Qty
                manulist = (foodname, Qty, total, name)
                usermanulist.append(manulist)

            elif select == '3':
                Qty = int(input("จำนวน : "))
                foodname = 'ซาลาเปาไส้หมูแดง '
                total = 10*Qty
                totallist = total + totallist
                manulist = (foodname,Qty,total,name)
                usermanulist.append(manulist)

            elif select == '4':
                Qty = int(input("จำนวน : "))
                foodname = 'ซาลาเปาไส้เผือก'
                total = 10*Qty
                totallist = total + totallist
                manulist = (foodname, Qty, total, name)
                usermanulist.append(manulist)

            elif select == '5':
                Qty = int(input("จำนวน : "))
                foodname = 'ไส้ครีม'
                total = 10*Qty
                totallist = total + totallist
                manulist = (foodname, Qty, total, name)
                usermanulist.append(manulist)

            elif select == '6':
                Qty = int(input("จำนวน : "))
                foodname = 'ขนมปังปิ้งเนยนม'
                total = 20*Qty
                totallist = total + totallist
                manulist = (foodname,Qty,total,name)
                usermanulist.append(manulist)

            elif select == '7':
                Qty = int(input("จำนวน : "))
                foodname = 'ขนมปังปิ้งแยมสตอเบอร์รี'
                total = 20*Qty
                totallist = total + totallist
                manulist = (foodname, Qty, total, name)
                usermanulist.append(manulist)

            elif select == '8':
                Qty = int(input("จำนวน : "))
                foodname = 'ขนมปังปิ้งเนย นม ช็อกโกแลต'
                total = 25*Qty
                totallist = total + totallist
                manulist = (foodname, Qty, total, name)
                usermanulist.append(manulist)

            elif select == '9':
                Qty = int(input("จำนวน : "))
                foodname = 'ขนมปังปิ้งแย้มส้ม'
                total = 20*Qty
                totallist = total + totallist
                manulist = (foodname, Qty, total, name)
                usermanulist.append(manulist)

            elif select == '10':
                Qty = int(input("จำนวน : "))
                foodname = 'น้ำเปล่า'
                total = 7*Qty
                totallist = total + totallist
                manulist = (foodname,Qty,total,name)
                usermanulist.append(manulist)

            elif select == '11':
                manuUserLog()
            else:
                print("Please try again")

            print(usermanulist)
            print(totallist)

            ch = input('คุณ' + name + 'ต้องการสั่งอาหารเพิ่มหรือไม่(y/n): ')
            if  ch == 'n':
                conf = input('คุณ' + name + 'ยืนยันการสั่งอาหารหรือไม่(y/n): ')
                if conf != 'n':
                    addDB(usermanulist)
                    print('+++++ ทำการยืนยันทำสั่งซื้ออเรียบร้อย +++++++')
                    mass = 'ยืนยันคำสั่งซื้อเรียบร้อย'
                    server.send(mass.encode('utf-8'))  # ส่งข้อความไปหาserver
                    data_server1 = server.recv(1024).decode('utf-8')
                    print("Data from server:" + data_server1)
                    data_server2 = server.recv(1024).decode('utf-8')
                    print("Data from server:" + data_server2)
                    data_server3 = server.recv(1024).decode('utf-8')
                    print("Data from server:" + data_server3)
                    if data_server3 == 'จัดส่งเรียบร้อยแล้วค่ะ/ครับ':
                        break


def login():
   username = input("please enter your username: ")
   server.send(username.encode('utf-8'))
   password = input("please enter your password: ")
   server.send(password.encode('utf-8'))

def newUser():
    username = input("please enter your username: ")
    server.send(username.encode('utf-8'))
    password = input("please enter your password: ")
    passwor1 = input("please reenter your password: ")
    while password!=passwor1:
            print("You paswords didn't , Please try again")
            password = input("please enter your password: ")
            passwor1 = input("please reenter your password: ")

    server.send(password.encode('utf-8'))
    server.send(passwor1.encode('utf-8'))

def manuUserLog():
   while True:
       print('-------------------------------------')
       print('Welcome to Users System')
       manu = ('''
       1. สมัครสมาชิก
       2. เข้าระบบ
       3. กลับ
       ''')
       print(manu)
       select = input("Choose your choice: ")
       if select=='1':
           data = 'newUser'
           server.send(data.encode('utf-8'))  # ส่งข้อความไปหาserver
           newUser()
           data_server = server.recv(1024).decode('utf-8')
           print("Data from server:" + data_server)
       elif select=='2':
           data = 'login'
           server.send(data.encode('utf-8'))  # ส่งข้อความไปหาserver
           login()
           data_server = server.recv(1024).decode('utf-8')
           print("Data from server:"+'Hello\t' + data_server)
           food(data_server)
       elif select == '3':
           print("Thank you")
           seletRoll()
       else:
           print("Please try again")

def manuAdminLog():
    while True:
        print('-------------------------------------')
        print('Welcome to Admin System')
        manu = ('''
        1. รายชื่อสมาชิก
        2. ประวิติการสั้งของสมาชิก
        3. กลับ
        ''')
        print(manu)
        select = input("Choose your choice: ")
        if select == '1':
            UsersList()

        elif select == '2':
            history()

        elif select == '3':
            print("Good Bye~ ~")
            seletRoll()

        else:
            print("Please try again")


def Adlogin():
    while True:
        username = input("please enter your username: ")
        password = input("please enter your password: ")
        if password == '7777':
            manuAdminLog()
        else:
            print("Please try again")


def seletRoll():
    while True:
        print('-------------------------------------')
        print('Welcome to Food Service System')
        manu = ('''
        1. Admin
        2. User
        3. Exit
        ''')
        print(manu)
        select = input("Choose your choice: ")
        if select == '1':
            data = 'Admin'
            server.send(data.encode('utf-8'))  # ส่งข้อความไปหาserver
            Adlogin()
        elif select == '2':
            data = 'User'
            server.send(data.encode('utf-8'))  # ส่งข้อความไปหาserver
            manuUserLog()
        elif select == '3':
            print("Good Bye~ ~")
            sys.exit()
        else:
            print("Please try again")

seletRoll()







