import sqlite3 as DB
#เชื่อมต่อฐานข้อมูล
con = DB.connect('FoodService.db')
with con:

    cur = con.cursor()#ตัว pionter เอาไว้ชี้ตำแหน่ง

    cur.execute("""create table users(
                    username varchar(20) primary key,
                    password varchar(20) not null)""")#สร้างตารางในdb//ถ้ารัน2รอบจะerror
    cur.execute("create table bill(foodname tex,Qty int,ttotalprice int ,user text)")


con.close()



